﻿# 03 - Description List
------
Problems for homework for the [“HTML and CSS Basics”](#) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/#!/List/ByCategory/165/HTML-and-CSS)

## Constraints
* Change the document **title**
* Use **h1** tag for the title
* Use **dl** tag for description list
    * Use **dt** tags to define data term
    * Use **dd** tags to define data definition (description)