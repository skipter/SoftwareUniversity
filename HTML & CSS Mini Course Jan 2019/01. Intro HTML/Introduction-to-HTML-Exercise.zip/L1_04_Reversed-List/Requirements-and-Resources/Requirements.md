﻿# 04 - Reversed List
------
Problems for homework for the [“HTML and CSS Basics”](#) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/#!/List/ByCategory/165/HTML-and-CSS)

## Constraints
* Change the document **title**
* Use **h3** tag for the title
* Use **ol reversed** for ordered reversed list
    * Add 4 **list items**